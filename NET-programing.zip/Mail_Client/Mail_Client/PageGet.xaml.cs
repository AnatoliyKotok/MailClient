﻿using MailKit;
using MailKit.Net.Imap;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mail_Client
{
    /// <summary>
    /// Interaction logic for PageGet.xaml
    /// </summary>
    public partial class PageGet : Page
    {
        NetworkCredential networkClient;
        ImapClient ImapClient = new ImapClient();
        public PageGet(NetworkCredential network)
        {
            InitializeComponent();
            networkClient = network;
            ImapClient.Connect("imap.gmail.com", 993, true);
            ImapClient.Authenticate(network.UserName, network.Password);
            foldersList.ItemsSource = GetFolders();
        }
        private void btSend_Click(object sender, RoutedEventArgs e)
        {
           
             frame.Content = new PageSend(new NetworkCredential(networkClient.UserName, networkClient.Password));
           
        }
        public IList<IMailFolder> GetFolders()
        {
            return ImapClient.GetFolders(ImapClient.PersonalNamespaces[0]).Skip(2).ToList();
        }
        

        private void foldersList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var item = foldersList.SelectedItem as IMailFolder;
            if (item != null)
            {
                frame.Content = new PageMessage(item);
            }
            
        }
    }
}

