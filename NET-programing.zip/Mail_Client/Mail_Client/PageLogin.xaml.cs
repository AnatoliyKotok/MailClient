﻿using EAGetMail;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mail_Client
{
    /// <summary>
    /// Interaction logic for PageLogin.xaml
    /// </summary>
    public partial class PageLogin : Page
    {
        ObservableCollection<User> users = new ObservableCollection<User>();
        User user = new User();
        public PageLogin()
        {
            InitializeComponent();
            cbUsers.ItemsSource = users;
            if (File.Exists("Users.txt"))
            {
                ReadUsersFromFile(users);
            }
            cbUsers.DisplayMemberPath = "Login";
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

            MailServer server = new MailServer("imap.gmail.com", tbLogin.Text, pbPass.Password, ServerProtocol.Imap4)
            {
                SSLConnection = true,
                Port = 993
            };
            user.Login = tbLogin.Text;
            user.Password = pbPass.Password;
          
            
                if (isExists(server))
                {
                    if (users.Contains(user) == false)
                    {
                        WriteUsersinFile(user);
                    }

                    this.NavigationService.Navigate(new PageGet(new NetworkCredential(tbLogin.Text, pbPass.Password)));
                }
           
        }

        private void WriteUsersinFile(User user)
        {
            using (StreamWriter writer = new StreamWriter(("Users.txt"), true))
            {
                writer.WriteLine($"{user.Login}\t{Encrypt(user.Password)}");
            }
        }
        private void ReadUsersFromFile(ObservableCollection<User> users)
        {
            var lines = File.ReadAllLines("Users.txt");
            foreach (var item in lines)
            {
                
                    string[] words = item.Split('\t');
                    User user = new User()
                    {
                        Login = words[0],
                        Password = Decrypt(words[1]),
                    };
                    users.Add(user);
                
            }
        }
        public static string Encrypt(string clearText)
        {
            string EncryptionKey = "abc123";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "abc123";
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
            Application.Current.Shutdown();
        }

        private void cbUsers_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            tbLogin.Text = (cbUsers.SelectedItem as User).Login;
            pbPass.Password = (cbUsers.SelectedItem as User).Password;
        }
        private bool isExists(MailServer server)
        {
            MailClient client = new MailClient("TryIt");
            try
            {
                client.Connect(server);
                return true;
            }
            catch (Exception)
            {
                MessageBox.Show("User is not exsists");
                return false;
            }

        }

    }
    class User
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public override bool Equals(object obj)
        {
            return this.Login == (obj as User).Login;
        }
        public override string ToString()
        {
            return $"{Login}";
        }
    }
}

