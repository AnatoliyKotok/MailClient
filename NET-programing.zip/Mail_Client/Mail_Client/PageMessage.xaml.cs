﻿using MailKit;
using Microsoft.Toolkit.Wpf.UI.Controls;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mail_Client
{
    /// <summary>
    /// Interaction logic for PageMessage.xaml
    /// </summary>
    public partial class PageMessage : Page
    {
        public PageMessage(IMailFolder folder)
        {
            InitializeComponent();
            this.DataContext = new MimeMessage();
            Thread task = new Thread(() =>
            {
                Application.Current.Dispatcher.Invoke(()=>{
                    messageList.ItemsSource = GetMessages(folder);
                });
            });
            task.Start();
        }

        public  IList<MimeMessage> GetMessages(IMailFolder folder)
        {


            folder.Open(FolderAccess.ReadOnly);
            List<MimeMessage> mimeMessage = new List<MimeMessage>(20);
            for (int i = 0; i <20; i++)
            {
                    mimeMessage.Add(folder.GetMessage(i));
            }
            return mimeMessage;
        }
               
        public class MyWebViewExtention
        {
            public static readonly DependencyProperty HtmlSourceProperty =
                   DependencyProperty.RegisterAttached("HtmlSource", typeof(string), typeof(MyWebViewExtention), new PropertyMetadata("", OnHtmlSourceChanged));
            public static string GetHtmlSource(DependencyObject obj) { return (string)obj.GetValue(HtmlSourceProperty); }
            public static void SetHtmlSource(DependencyObject obj, string value) { obj.SetValue(HtmlSourceProperty, value); }
            private static void OnHtmlSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
            {
                WebView webView = d as WebView;
                webView?.NavigateToString((string)e.NewValue);
               
                
            }
        }

        private void messageList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = messageList.SelectedItem as MimeMessage;
            if (item != null)
            {

            }
        }
    }
           


                
        
}
