﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mail_Client
{
    /// <summary>
    /// Interaction logic for PageSend.xaml
    /// </summary>
    public partial class PageSend : Page
    {
        string server = "smtp.gmail.com"; // sets the server address
        int port = int.Parse(ConfigurationManager.AppSettings["gmail_port"]);
        List<string> items = new List<string>();
        NetworkCredential clientNetwork;
        public PageSend(NetworkCredential network)
        {
            InitializeComponent();
            cbPriority.ItemsSource = Enum.GetValues(typeof(MailPriority));
            clientNetwork = network;
            tbFrom.Text = network.UserName;
        }

        private void btAdd_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.ShowDialog();
            items.Add(fileDialog.FileName);
            lbItem.Items.Add(fileDialog.FileName);
        }
        private void Client_SendCompleted(object sender, AsyncCompletedEventArgs e)
        {
            MessageBox.Show($"Message was sent! Token:{e.UserState}");
        }
        private void btSend_Click(object sender, RoutedEventArgs e)
        {


            MailMessage message = new MailMessage(tbFrom.Text, tbTo.Text, tbTo.Text, tbMessage.Text);
            message.Priority = (MailPriority)cbPriority.SelectedItem;
            foreach (var item in items)
            {
                message.Attachments.Add(new Attachment(item));
            }
            SmtpClient client = new SmtpClient(server, port);
            client.EnableSsl = true;

            // settings for sending mail
            client.Credentials = clientNetwork;

            client.SendCompleted += Client_SendCompleted;

            // call asynchronous message sending
            client.SendAsync(message, "blabla");
        }
    }
}

